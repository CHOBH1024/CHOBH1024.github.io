import React, { useState, useEffect } from 'react';
import { Icon } from './Icon';
import { Archetype, SavedTeam } from '../types';
import { archetypes } from '../data';

interface TeamBuilderProps {
    myArchetype: Archetype;
}

type Category = 'VISION' | 'STRUCTURE' | 'RELATION' | 'ACTION';

// Helper to categorize archetypes
const getCategory = (id: number): Category => {
    if ([1, 8, 3].includes(id)) return 'VISION'; // Head/Will: 설계자, 비전가, 수호자
    if ([4, 6].includes(id)) return 'STRUCTURE'; // Body/Form: 살림꾼, 교육가
    if ([2, 7, 9].includes(id)) return 'RELATION'; // Heart: 부모, 중재자, 예술가
    if ([5].includes(id)) return 'ACTION'; // Hands/Feet: 기동대장
    return 'VISION';
};

const getCategoryInfo = (cat: Category) => {
    switch(cat) {
        case 'VISION': return { label: "비전 (Vision)", color: "text-purple-700 bg-purple-50 border-purple-200", icon: "Crown" };
        case 'STRUCTURE': return { label: "체계 (System)", color: "text-blue-700 bg-blue-50 border-blue-200", icon: "Castle" };
        case 'RELATION': return { label: "관계 (Relation)", color: "text-pink-700 bg-pink-50 border-pink-200", icon: "HeartHandshake" };
        case 'ACTION': return { label: "실행 (Action)", color: "text-amber-700 bg-amber-50 border-amber-200", icon: "Flame" };
    }
};

// Specific Team Role Definitions for each Archetype ID with Visuals
const teamRoleDefinitions: Record<number, { roleName: string; contribution: string; task: string; icon: string; theme: string }> = {
    1: { 
        roleName: "규율 반장 (Discipline Officer)", 
        contribution: "천법(天法)을 수호하듯 팀의 원칙과 마감을 엄수하게 합니다. 감정에 치우친 의사결정을 막고 '창조 질서'를 확립합니다.", 
        task: "프로젝트 일정 관리(PM), 회의록 및 규정 검수, R&R(역할분담) 명확화",
        icon: "Scale",
        theme: "slate"
    },
    2: { 
        roleName: "케어 매니저 (Care Manager)", 
        contribution: "어머니의 심정으로 팀원들의 영적 컨디션을 살핍니다. 딱딱한 업무 관계를 '식구'의 인연으로 승화시키는 윤활유입니다.", 
        task: "팀 빌딩 및 회식 기획, 구성원 생일/경조사 챙기기, 갈등 발생 시 심정적 중재",
        icon: "HeartHandshake",
        theme: "pink"
    },
    3: { 
        roleName: "영적 나침반 (Spiritual Compass)", 
        contribution: "팀이 세속적인 성공에 취해 섭리적 본질을 잃지 않도록 경계합니다. 항상 '이것이 하늘의 뜻인가?'를 묻습니다.", 
        task: "기획안의 원리적 검토, 회의 시작 전 훈독회 인도, 비전 정렬(Alignment) 확인",
        icon: "Compass",
        theme: "purple"
    },
    4: { 
        roleName: "보급관 (Supply Officer)", 
        contribution: "요셉과 같이 풍년과 흉년을 대비하며 물적 토대를 관리합니다. 팀원들이 마음껏 활동할 수 있도록 후방을 든든히 지킵니다.", 
        task: "회계 및 예산 관리, 비품 구입 및 장소 예약, 각종 행정 절차 처리",
        icon: "Briefcase",
        theme: "blue"
    },
    5: { 
        roleName: "선봉장 (Vanguard)", 
        contribution: "가장 험난한 섭리 완성의 최전선에 먼저 뛰어듭니다. 말보다 행동으로 보여주며 팀의 패배주의를 깨뜨립니다.", 
        task: "외부 인사 섭외, 현장 답사 및 개척, 난관 돌파, 분위기 메이킹(Cheerleading)",
        icon: "Flame",
        theme: "red"
    },
    6: { 
        roleName: "전략가 (Strategist)", 
        contribution: "방대한 섭리적 아이디어를 논리적인 체계로 정리합니다. 외부인들도 이해할 수 있는 설득력 있는 논리를 개발합니다.", 
        task: "기획서 및 제안서 작성, 프레젠테이션(PPT) 제작, 자료 조사 및 데이터 분석",
        icon: "Map",
        theme: "indigo"
    },
    7: { 
        roleName: "피스메이커 (Peacemaker)", 
        contribution: "구성원 간의 갈등을 중재하고 화합을 이끌어냅니다. 누구 하나 소외되지 않도록 전체의 조화를 조율합니다.", 
        task: "회의 진행(Moderator), 내부 갈등 중재, 대외 협력 및 연락 창구 담당",
        icon: "Wheat",
        theme: "green"
    },
    8: { 
        roleName: "혁신가 (Innovator)", 
        contribution: "고정관념을 깨고 '새 술을 새 부대'에 담습니다. 매너리즘에 빠진 팀에 창조적 충격을 주어 섭리를 갱신합니다.", 
        task: "브레인스토밍 주도, 새로운 트렌드 및 기술 리서치, 프로토타입(시안) 제작",
        icon: "Sparkles",
        theme: "amber"
    },
    9: { 
        roleName: "감성 디렉터 (Art Director)", 
        contribution: "천일국의 문화를 아름답게 표현하여 사람들의 심금을 울립니다. 삭막한 기능 조직에 예술적 영성을 불어넣습니다.", 
        task: "홍보물 및 포스터 디자인, 영상 촬영/편집, 공간 연출 및 데코레이션",
        icon: "Feather",
        theme: "rose"
    }
};

const getThemeClasses = (theme: string) => {
    switch(theme) {
        case 'slate': return { bg: 'bg-slate-50', border: 'border-slate-200', text: 'text-slate-700', iconBg: 'bg-slate-100', accent: 'border-slate-400' };
        case 'pink': return { bg: 'bg-pink-50', border: 'border-pink-200', text: 'text-pink-700', iconBg: 'bg-pink-100', accent: 'border-pink-400' };
        case 'purple': return { bg: 'bg-purple-50', border: 'border-purple-200', text: 'text-purple-700', iconBg: 'bg-purple-100', accent: 'border-purple-400' };
        case 'blue': return { bg: 'bg-blue-50', border: 'border-blue-200', text: 'text-blue-700', iconBg: 'bg-blue-100', accent: 'border-blue-400' };
        case 'red': return { bg: 'bg-red-50', border: 'border-red-200', text: 'text-red-700', iconBg: 'bg-red-100', accent: 'border-red-400' };
        case 'indigo': return { bg: 'bg-indigo-50', border: 'border-indigo-200', text: 'text-indigo-700', iconBg: 'bg-indigo-100', accent: 'border-indigo-400' };
        case 'green': return { bg: 'bg-green-50', border: 'border-green-200', text: 'text-green-700', iconBg: 'bg-green-100', accent: 'border-green-400' };
        case 'amber': return { bg: 'bg-amber-50', border: 'border-amber-200', text: 'text-amber-700', iconBg: 'bg-amber-100', accent: 'border-amber-400' };
        case 'rose': return { bg: 'bg-rose-50', border: 'border-rose-200', text: 'text-rose-700', iconBg: 'bg-rose-100', accent: 'border-rose-400' };
        default: return { bg: 'bg-stone-50', border: 'border-stone-200', text: 'text-stone-700', iconBg: 'bg-stone-100', accent: 'border-stone-400' };
    }
};

interface ChemistryData {
    title: string;
    desc: string;
    strength: string;
    weakness: string;
    score: number;
    advice: string;
    communication: string;
    conflictTrigger: string;
    futureForecast: string;
    meetingStyle: string; // 회의 스타일
    decisionMethod: string; // 의사결정 방식
    leaderStaffDynamic: string; // 리더-스태프 역학
    pastorMemberDynamic: string; // 목회자-식구 역학
    strategicGoal: string; // 팀 특화 섭리 목표
    strategicTheme: string; // 목표의 슬로건
    actionPlanShort: string; // 단기 3개월 과제
    actionPlanLong: string; // 장기 1년 과제
    careerRoadmap: string; // 개인별 커리어 로드맵
    tags: string[];
}

// ... (getDyadChemistry and getTriadChemistry logic remains the same) ...
// For brevity, using the existing full implementations of getDyadChemistry and getTriadChemistry
const getDyadChemistry = (c1: Category, c2: Category): ChemistryData => {
    const cats = [c1, c2].sort();
    const key = cats.join('-');
    const info1 = getCategoryInfo(c1);
    const info2 = getCategoryInfo(c2);

    const baseData = {
        tags: [info1.label, info2.label],
        score: 0
    };

    switch(key) {
        case 'VISION-VISION': return {
            ...baseData,
            title: "영적 주체들의 연합 (Alliance of Subjects)",
            desc: "두 분은 섭리의 '방향'과 '본질'을 놓고 밤새워 토론할 수 있는 영적 도반입니다. 영적인 주파수가 공명할 때 엄청난 계시적 에너지가 발생하지만, 현실적인 행정/재정 기반이 부족하여 '구름 위의 성'만 짓다 끝날 위험이 큽니다.",
            strength: "강력한 영적 동기부여, 섭리적 방향성의 거시적 일치, 서로의 꿈을 지지하는 계시적 대화",
            weakness: "실체적 기반의 부재, 구체적인 실행 계획 결여, 현실 도피적 경향",
            score: 70,
            advice: "말씀(Logos)은 육신(Flesh)을 입어야 완성됩니다. 회의 끝에 반드시 '누가, 언제, 무엇을' 할 것인지 기록하는 실무 서기를 두십시오.",
            communication: "추상적이고 신학적인 언어, 서로 말을 끊고 아이디어를 얹는 상승 대화 패턴.",
            conflictTrigger: "서로 '네가 실무를 하겠지'라고 미루다 아무것도 진행되지 않았을 때.",
            futureForecast: "원대한 '천일국 헌법'은 만들었으나, 정작 그것을 지키고 살아갈 백성이 없는 공허한 상황.",
            meetingStyle: "끝장 토론형. 정해진 안건 없이 섭리의 역사부터 미래까지 이야기하다가 정작 오늘 결정해야 할 사항은 못 정하고 끝남.",
            decisionMethod: "영감 의존형. '기도해 보니 이렇더라'는 직관에 의해 결정하며, 데이터나 예산 제약은 무시되는 경향.",
            leaderStaffDynamic: "리더가 거창한 지시를 내리면 스태프도 거창하게 화답하지만, 둘 다 구체적인 보고서는 안 씀.",
            pastorMemberDynamic: "목회자가 비전을 선포하면 식구는 '아멘'하고 감동받지만, 집에 가면 '그래서 헌금을 얼마나 내라는 거지?'라고 의문.",
            strategicGoal: "신학적 비전의 커리큘럼화 및 교재 편찬",
            strategicTheme: "말씀의 실체화 (Substantiation of Logos)",
            actionPlanShort: "3개월 내: 뜬구름 잡는 비전을 정리하여 '표준 강의안' 1건 완성 및 시범 강의.",
            actionPlanLong: "1년 내: 정리된 말씀을 바탕으로 '평생 교육원' 설립 또는 정기 아카데미 런칭.",
            careerRoadmap: "비전가1: 사상연구원장/교육국장 코스 (이론 정립) | 비전가2: 부흥단장/순회강사 코스 (대중 설파)"
        };
        case 'STRUCTURE-VISION': return {
            ...baseData,
            title: "주체와 대상의 창조적 수수작용 (Subject-Object Unity)",
            desc: "비전(마음)과 체계(몸)가 만난 가장 이상적인 '심신일체' 모델입니다. 비전가가 청사진을 제시하면 체계가가 현실적인 기반을 제공하여 무형의 뜻을 유형의 실적으로 안착시킵니다.",
            strength: "비전의 실체화 능력, 안정과 성장의 균형, 높은 업무 완결성",
            weakness: "속도 조절 갈등, 혁신과 안주의 충돌",
            score: 98,
            advice: "비전가는 제동을 '불신'으로 오해 말고, 체계가는 '안 된다' 대신 '이렇게 하면 된다'는 대안을 제시하십시오.",
            communication: "비전가는 'Why'를 말하고 체계가는 'How'를 묻는 상호보완적 대화.",
            conflictTrigger: "비전가가 절차를 무시하고 독단적으로 섭리를 강행할 때.",
            futureForecast: "내실과 외형을 모두 갖춘 섭리적 모델 교회가 건축될 것입니다.",
            meetingStyle: "가장 생산적인 회의. 비전가가 아이디어를 던지면 체계가가 노트북을 켜고 예산과 일정을 시뮬레이션함.",
            decisionMethod: "합의형. 비전가가 방향을 잡고 체계가가 속도를 조절하여 리스크를 최소화.",
            leaderStaffDynamic: "리더(비전)가 꿈을 꾸면 스태프(체계)가 그것을 문서화하고 매뉴얼로 만듦. 완벽한 비서실장.",
            pastorMemberDynamic: "목회자가 영적 비전을 제시하면, 핵심 식구(장로/권사)가 살림을 맡아 뒷받침함.",
            strategicGoal: "자립형 모델 교회 구축 및 시스템 표준화",
            strategicTheme: "시스템에 의한 섭리 (Providence by System)",
            actionPlanShort: "3개월 내: 교회/조직의 정관 및 재무 규정 정비, 주간 업무 보고 체계 확립.",
            actionPlanLong: "1년 내: 재정 자립도 100% 달성 및 타 교회가 벤치마킹할 수 있는 '운영 매뉴얼' 배포.",
            careerRoadmap: "비전가: 교구장/대교구장 (조직 총괄) | 체계가: 재단 사무총장/기획조정실장 (살림 총괄)"
        };
        case 'ACTION-VISION': return {
            ...baseData,
            title: "출애굽의 기적 (Exodus Command)",
            desc: "말씀(Vision)과 실천(Action)이 결합된 강력한 개척자 팀입니다. 모세와 여호수아처럼 거친 환경을 돌파합니다. 정체된 조직에 영적 태풍을 일으킵니다.",
            strength: "압도적인 추진력, 빠른 섭리 완성, 역동적인 현장 변화",
            weakness: "디테일 부족, 잦은 시행착오, '믿으면 된다' 식의 무모함",
            score: 85,
            advice: "속도보다 중요한 것은 방향과 안전입니다. 정기 점검(Review) 시간을 강제로 편성하십시오.",
            communication: "짧고 간결하며 직설적. '돌격 앞으로' 식의 구호 난무.",
            conflictTrigger: "결과가 나쁠 때 서로 '네 믿음이 부족했다'며 영적 비난을 할 때.",
            futureForecast: "외연은 확장되었으나 내실이 부족하여 대대적인 보수가 필요함.",
            meetingStyle: "작전회의형. 앉아서 이야기하기보다 서서 지도 펴놓고 '언제 출발할까'만 논의함.",
            decisionMethod: "톱다운(Top-down)형. 리더가 결정하면 즉시 실행. 신중론은 '믿음 없음'으로 간주.",
            leaderStaffDynamic: "리더가 '고지 점령'을 외치면 스태프는 총 들고 뛰어나감. 번아웃 주의.",
            pastorMemberDynamic: "목회자가 '성전 건축합시다!' 하면 식구들이 집 팔아서 헌금하는 뜨거운 분위기.",
            strategicGoal: "신규 식구 전도 및 섭리 영토 확장",
            strategicTheme: "중단 없는 전진 (Unstoppable Advance)",
            actionPlanShort: "3개월 내: 전도 특공대 조직 및 거리 캠페인 100회 실시, 신규 식구 30명 목표.",
            actionPlanLong: "1년 내: 지교회 1개 개척 또는 센터 설립, 지역 사회 영향력 1위 달성.",
            careerRoadmap: "비전가: 개척교회장/해외 선교사 (영토 확장) | 행동가: CARP/청년 담당관/현장 소장 (실적 달성)"
        };
        case 'RELATION-STRUCTURE': return {
            ...baseData,
            title: "가정교회의 안주인 (Home Church Keepers)",
            desc: "안정적인 울타리(체계) 안에서 식구들을 따뜻하게 돌보는(관계) 어머니 같은 팀입니다. 가정교회나 소그룹 관리에 최적화되어 있습니다.",
            strength: "가장 안정적인 목회 환경, 높은 식구 만족도, 정착률 증가",
            weakness: "야성 상실, 현상 유지 편향, 폐쇄성",
            score: 88,
            advice: "내부의 평안함에 안주하지 말고 창문을 열어 바깥바람을 쐬어야 합니다.",
            communication: "부드럽고 예의 바르며 갈등을 회피하는 우회적 화법.",
            conflictTrigger: "체계가가 원칙을 내세워 식구를 차갑게 대할 때.",
            futureForecast: "내적으로 단단한 가족이 되지만 고령화될 위험.",
            meetingStyle: "반상회형. 다과를 먹으며 화기애애하게 시작해서 행정 공지를 부드럽게 전달.",
            decisionMethod: "만장일치 지향형. 한 사람이라도 반대하면 결정을 미룸. 변화보다 안정 선택.",
            leaderStaffDynamic: "리더가 꼼꼼히 챙기면서 스태프의 사정을 봐줌. 가족 같은 관계.",
            pastorMemberDynamic: "목회자가 식구들의 숟가락 개수까지 아는 관계. 교회를 '내 집'처럼 느낌.",
            strategicGoal: "새식구 정착률 제고 및 축복가정 관리",
            strategicTheme: "양육과 돌봄 (Nurture and Care)",
            actionPlanShort: "3개월 내: 전 식구 심방 완료 및 구역 조직 재편, 소그룹 리더 교육.",
            actionPlanLong: "1년 내: 식구 이탈률 0% 도전, 3대권이 함께하는 주일학교 시스템 정착.",
            careerRoadmap: "관계가: 가정국장/상담센터장 (내적 목회) | 체계가: 교회 사무장/복지재단 관리자 (살림 목회)"
        };
        default: return {
            ...baseData,
            title: "복합 섭리팀", desc: "서로 다른 특성이 섞여 있습니다.", strength: "상호 보완", weakness: "초기 조율 비용", score: 80, advice: "대화가 필요합니다.",
            communication: "노력 필요", conflictTrigger: "관점 차이", futureForecast: "조율에 달림",
            meetingStyle: "일반적", decisionMethod: "다수결", leaderStaffDynamic: "상호 존중", pastorMemberDynamic: "다양성 인정",
            strategicGoal: "팀워크 향상", strategicTheme: "화합", actionPlanShort: "워크숍", actionPlanLong: "프로젝트 완수", careerRoadmap: "각자 전문성 개발"
        };
    }
};

const getTriadChemistry = (c1: Category, c2: Category, c3: Category): ChemistryData => {
    const cats = [c1, c2, c3].sort();
    const key = cats.join('-');
    const tags = [getCategoryInfo(c1).label, getCategoryInfo(c2).label, getCategoryInfo(c3).label];
    
    const baseData = { tags, score: 0 };

    switch(key) {
        case 'RELATION-STRUCTURE-VISION': // V-S-R
            return {
                ...baseData,
                title: "이상적 사위기대 (Ideal Four Position Foundation)",
                desc: "하늘(비전), 땅(체계), 사람(관계)이 만난 섭리의 가장 이상적인 '안착 시대' 모델입니다. 3대상이 하나 되어 어떤 시련이 와도 무너지지 않는 자생력을 갖습니다.",
                strength: "완벽한 삼각 구도, 정책과 현장의 일치, 지속 가능한 성장",
                weakness: "합의 과정 비용, 야성 부족, 초기 조율의 어려움",
                score: 98,
                advice: "안주하지 않으려면 끊임없이 새로운 목표를 갱신해야 합니다. 만장일치를 지향하되 책임자를 명확히 하십시오.",
                communication: "균형 잡힌 3박자. 비전, 현실, 사람 이야기가 골고루 오감.",
                conflictTrigger: "비전가가 앞서가려 할 때 체계가가 제동 걸고 관계가가 눈치 보는 상황.",
                futureForecast: "1년 후 내실과 외형을 갖춘 모델 교회로 선정될 것.",
                meetingStyle: "국회 의사당형. 치열하게 토론하지만 가장 합리적이고 포용적인 결론 도출.",
                decisionMethod: "삼권분립형. 비전 제안 -> 관계 동의 -> 체계 승인. 견제와 균형 완벽.",
                leaderStaffDynamic: "누가 리더가 되어도 나머지 둘이 보좌하는 '어벤져스' 팀.",
                pastorMemberDynamic: "목회자는 존경받고, 장로(체계)는 신뢰받고, 권사(관계)는 사랑받음.",
                strategicGoal: "천일국 모델 교회 구축 및 복제",
                strategicTheme: "완전한 균형 (Perfect Balance)",
                actionPlanShort: "3개월 내: 비전 선포식 개최, 부서별 R&R 재정립, 소그룹 리더 12명 세우기.",
                actionPlanLong: "1년 내: 출석 식구 20% 성장, 재정 투명성 확보, 지역 사회 봉사 프로그램 정례화.",
                careerRoadmap: "비전가: 본부장/대륙회장 (종합 리더십) | 체계가: 재단 이사장/행정국장 (경영 전문성) | 관계가: 수련원장/가정연합 회장 (심정적 구심점)"
            };
        case 'ACTION-RELATION-VISION': // V-R-A
            return {
                ...baseData,
                title: "성령의 부흥단 (The Revival Trinity)",
                desc: "말씀(비전), 사랑(관계), 실천(행동)이 결합된 '오순절' 팀입니다. 체계에 얽매이지 않고 성령을 따라 움직이며 폭발적인 에너지를 발휘합니다.",
                strength: "강력한 영적 파동, 빠른 현장 장악력, 폭발적 전도",
                weakness: "체계 부족으로 인한 혼란, 재정 관리 허점, 지속 가능성 위기",
                score: 95,
                advice: "부흥의 불길을 담을 '그릇(체계)'을 외부에서라도 빌려오십시오. 기록과 재정을 남기는 훈련이 필요합니다.",
                communication: "은혜와 간증이 넘치는 대화. '할 수 있다'는 격려 위주.",
                conflictTrigger: "일이 꼬이거나 재정 사고 시 책임 소재 불분명.",
                futureForecast: "수많은 전도 실적을 냈으나 관리가 안 되어 정착률은 미지수.",
                meetingStyle: "기도회형. 회의하다가 통성기도하고 '성령이 시키시는 대로' 결정.",
                decisionMethod: "만장일치 결의형. 분위기에 휩쓸려 결정. 구체적 계획은 나중.",
                leaderStaffDynamic: "리더가 깃발 들면 스태프들이 춤추며 따라감. 월급 밀려도 참음.",
                pastorMemberDynamic: "매일이 축제. 하지만 행정 처리가 늦어 민원 발생 가능.",
                strategicGoal: "지역 복음화 및 대형 집회 성공",
                strategicTheme: "영적 대각성 (Spiritual Awakening)",
                actionPlanShort: "3개월 내: 100일 특별 정성 및 노방 전도 캠페인, 부흥 집회 3회 개최.",
                actionPlanLong: "1년 내: 신규 전도 120명 달성, 문화 예술 선교단 창단.",
                careerRoadmap: "비전가: 부흥사/순회강사 (영적 지도자) | 행동가: 선교 현장 소장 (개척자) | 관계가: 목양 담당 목사 (식구 케어)"
            };
        case 'ACTION-STRUCTURE-VISION': // V-S-A
            return {
                ...baseData,
                title: "천일국 건설단 (Construction Corps)",
                desc: "사랑(Relation)이 빠지고 과업 달성을 위해 뭉친 특수부대입니다. 비전-행동-체계가 맞물려 불가능한 목표를 돌파해냅니다.",
                strength: "최고의 업무 효율, 목표 초과 달성, 신속한 섭리 진행",
                weakness: "심정의 고갈, 구성원의 도구화, 삭막한 분위기, 부상자 발생",
                score: 90,
                advice: "일은 성공했으나 사람은 잃을 수 있습니다. '티타임'과 '교제'를 필수 과업으로 넣으십시오.",
                communication: "군대식 보고와 지시. 감정 호소는 '나약함'으로 취급.",
                conflictTrigger: "성과 부진 시 상호 비난, 행동가의 독단과 체계가의 통제 충돌.",
                futureForecast: "외적 성전은 완공되었으나 내부는 차갑게 식어있을 수 있음.",
                meetingStyle: "작전 상황실형. 데이터 띄워놓고 달성률 체크. 진지함.",
                decisionMethod: "목표 지향적 독재. 효율성이 최고 가치. 사람 사정 고려 안 함.",
                leaderStaffDynamic: "강력한 리더십과 유능한 참모. 퇴근 후엔 남남.",
                pastorMemberDynamic: "교회는 성장하고 건물도 짓지만, 식구들은 지쳐있음.",
                strategicGoal: "성전 건축 및 섭리 기관 설립",
                strategicTheme: "실체적 기매 구축 (Foundation Building)",
                actionPlanShort: "3개월 내: 건축 기금 모금 달성, 부지 매입 및 인허가 완료.",
                actionPlanLong: "1년 내: 성전 봉헌식 거행 및 섭리 기업 흑자 전환.",
                careerRoadmap: "비전가: CEO/기관장 (경영자) | 행동가: 건설본부장/영업이사 (현장 지휘) | 체계가: CFO/감사실장 (관리자)"
            };
        default: return { 
            ...baseData, title: "복합 섭리팀", desc: "분석 중...", strength: "", weakness: "", score: 80, advice: "서로의 강점에 집중하십시오.", 
            communication: "서로 다른 스타일 이해 필요", conflictTrigger: "관점 차이", futureForecast: "조율 여하에 달림",
            meetingStyle: "혼합형", decisionMethod: "상황에 따라 다름", leaderStaffDynamic: "상호 존중 필요", pastorMemberDynamic: "다양성 인정",
            strategicGoal: "팀 빌딩 및 역할 정립", strategicTheme: "하나됨 (Unity)", actionPlanShort: "워크숍을 통한 서로 알기", actionPlanLong: "공동 프로젝트 완수",
            careerRoadmap: "각자의 강점을 살린 전문 분야 개척"
        };
    }
};

export const TeamBuilder: React.FC<TeamBuilderProps> = ({ myArchetype }) => {
    const [partners, setPartners] = useState<Archetype[]>([]);
    const [teamName, setTeamName] = useState('');
    const [savedTeams, setSavedTeams] = useState<SavedTeam[]>([]);

    useEffect(() => {
        const stored = localStorage.getItem('cig_saved_teams');
        if (stored) {
            try {
                const parsed = JSON.parse(stored);
                setSavedTeams(parsed);
            } catch (e) {
                console.error("Failed to parse saved teams", e);
            }
        }
    }, []);

    const togglePartner = (archetype: Archetype) => {
        if (archetype.id === myArchetype.id) return; 
        
        if (partners.find(p => p.id === archetype.id)) {
            setPartners(partners.filter(p => p.id !== archetype.id));
        } else {
            if (partners.length < 2) {
                setPartners([...partners, archetype]);
            } else {
                alert("팀 시뮬레이션은 본인 포함 최대 3명까지만 가능합니다.");
            }
        }
    };

    const handleSaveTeam = () => {
        if (partners.length === 0) {
            alert("파트너를 최소 1명 이상 선택해주세요.");
            return;
        }
        if (!teamName.trim()) {
            alert("팀 이름을 입력해주세요.");
            return;
        }

        if (savedTeams.some(t => t.name.trim() === teamName.trim())) {
             alert("이미 동일한 이름의 팀이 존재합니다. 다른 이름을 사용해주세요.");
             return;
        }

        const newTeam: SavedTeam = {
            id: Date.now().toString(),
            name: teamName,
            myArchetypeId: myArchetype.id,
            partnerIds: partners.map(p => p.id),
            createdAt: Date.now()
        };

        const updatedTeams = [newTeam, ...savedTeams];
        setSavedTeams(updatedTeams);
        localStorage.setItem('cig_saved_teams', JSON.stringify(updatedTeams));
        setTeamName('');
        alert("팀이 저장되었습니다.");
    };

    const handleDeleteTeam = (id: string) => {
        if (confirm("정말 이 팀 기록을 삭제하시겠습니까?")) {
            const updatedTeams = savedTeams.filter(t => t.id !== id);
            setSavedTeams(updatedTeams);
            localStorage.setItem('cig_saved_teams', JSON.stringify(updatedTeams));
        }
    };

    const handleLoadTeam = (team: SavedTeam) => {
        if (team.myArchetypeId !== myArchetype.id) {
            if (!confirm("이 팀은 다른 아키타입(본인)을 기준으로 생성되었습니다. 그래도 불러오시겠습니까? 결과가 다를 수 있습니다.")) {
                return;
            }
        }
        
        const loadedPartners = team.partnerIds
            .map(id => archetypes.find(a => a.id === id))
            .filter((a): a is Archetype => !!a);
            
        setPartners(loadedPartners);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const team = [myArchetype, ...partners];
    const isDyad = team.length === 2;
    const isTriad = team.length === 3;
    const categories = team.map(m => getCategory(m.id));
    
    // --- Rich Analysis Logic ---
    let teamAnalysis: ChemistryData = {
        title: "팀 시뮬레이션 대기 중",
        desc: "파트너를 선택하면 분석 결과가 여기에 표시됩니다.",
        strength: "",
        weakness: "",
        advice: "",
        score: 0,
        tags: [],
        communication: "",
        conflictTrigger: "",
        futureForecast: "",
        meetingStyle: "",
        decisionMethod: "",
        leaderStaffDynamic: "",
        pastorMemberDynamic: "",
        strategicGoal: "",
        strategicTheme: "",
        actionPlanShort: "",
        actionPlanLong: "",
        careerRoadmap: ""
    };

    // Dyad Logic
    if (isDyad) {
        teamAnalysis = getDyadChemistry(categories[0], categories[1]);
    } 
    // Triad Logic
    else if (isTriad) {
        teamAnalysis = getTriadChemistry(categories[0], categories[1], categories[2]);
    }

    const renderAnalysis = () => {
        if (!isDyad && !isTriad) return (
            <div className="text-center text-stone-400 py-24 bg-stone-50 rounded-3xl border-2 border-dashed border-stone-200 flex flex-col items-center justify-center min-h-[500px] hover:bg-stone-100 transition-colors">
                <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mb-8 shadow-sm border border-stone-100">
                    <Icon name="Users" size={48} className="text-stone-300"/>
                </div>
                <h4 className="text-2xl font-bold text-slate-600 mb-3 font-serif">팀 시뮬레이션 시작하기</h4>
                <p className="max-w-md mx-auto leading-relaxed text-slate-500">
                    위 리스트에서 함께할 파트너를 <strong className="text-blue-900">1명(Dyad)</strong> 또는 <strong className="text-blue-900">2명(Triad)</strong> 선택해보세요.<br/>
                    단순한 조합을 넘어선, <strong>심층적인 화학 반응</strong>을 시뮬레이션합니다.
                </p>
            </div>
        );

        return (
            <div className="space-y-8 animate-[fadeIn_0.5s_ease-out]">
                {/* Save Team Bar */}
                <div className="bg-slate-800 p-4 rounded-xl flex flex-col md:flex-row gap-4 items-center justify-between shadow-lg">
                    <div className="text-white flex items-center gap-2">
                        <Icon name="Save" size={20} className="text-amber-400"/>
                        <span className="font-bold">현재 팀 저장하기</span>
                    </div>
                    <div className="flex gap-2 w-full md:w-auto">
                        <input 
                            type="text" 
                            value={teamName}
                            onChange={(e) => setTeamName(e.target.value)}
                            placeholder="팀 이름 (예: 2024 기획팀)"
                            className="flex-grow md:w-64 px-4 py-2 rounded-lg text-sm bg-slate-700 text-white border border-slate-600 focus:outline-none focus:border-amber-500 placeholder-slate-400"
                        />
                        <button 
                            onClick={handleSaveTeam}
                            className="bg-amber-600 hover:bg-amber-500 text-white px-4 py-2 rounded-lg text-sm font-bold transition-colors flex items-center gap-2"
                        >
                            <Icon name="Save" size={16}/> 저장
                        </button>
                    </div>
                </div>

                {/* 1. Main Dashboard Card */}
                <div className="bg-white rounded-3xl overflow-hidden shadow-xl border border-stone-200">
                    <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-10 relative overflow-hidden">
                         <div className="absolute top-0 right-0 p-12 opacity-5 rotate-12">
                            <Icon name="Users" size={200} />
                        </div>
                        <div className="relative z-10">
                            <div className="flex gap-2 mb-6">
                                {teamAnalysis.tags.map((tag, i) => (
                                    <span key={i} className="px-3 py-1 bg-white/10 backdrop-blur-sm rounded-full text-sm font-bold border border-white/20 uppercase tracking-wider">
                                        {tag}
                                    </span>
                                ))}
                            </div>
                            <h3 className="text-3xl md:text-5xl font-serif font-bold mb-4 leading-tight word-keep break-keep">{teamAnalysis.title}</h3>
                            <div className="flex flex-col md:flex-row md:items-center gap-6 mt-8">
                                <div className="flex items-center gap-3">
                                    <div className="text-sm text-slate-300 uppercase tracking-widest font-bold text-xs">Chemistry<br/>Score</div>
                                    <span className="text-5xl font-black text-amber-400 tracking-tight">{teamAnalysis.score}</span>
                                </div>
                                <div className="hidden md:block h-12 w-px bg-white/20"></div>
                                <div className="text-base text-slate-300 max-w-lg leading-relaxed">
                                    {isDyad ? "2인(Dyad) 관계는 서로를 마주보는 거울과 같습니다. '주체와 대상'의 수수작용이 원만할 때 섭리는 발전합니다." : "3인(Triad) 팀은 '사위기대'의 기초입니다. 하늘부모님을 중심에 두고 3대상이 하나 될 때 이상적인 기초가 닦입니다."}
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div className="p-8 md:p-10">
                        {/* Strategic Goal Section (NEW) */}
                        <div className="mb-12 bg-gradient-to-br from-blue-900 to-indigo-900 rounded-2xl p-8 text-white shadow-lg relative overflow-hidden">
                            <div className="absolute top-0 right-0 p-4 opacity-10"><Icon name="Target" size={150}/></div>
                            <h4 className="text-amber-400 font-bold tracking-widest uppercase mb-2 text-sm">Strategic Mission</h4>
                            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">{teamAnalysis.strategicGoal || "분석 중..."}</h2>
                            <p className="text-blue-200 text-xl font-medium italic">"{teamAnalysis.strategicTheme || "..."}"</p>
                        </div>

                        {/* Analysis Description */}
                        <div className="mb-12">
                            <h4 className="font-bold text-slate-900 mb-4 flex items-center gap-2 text-lg">
                                <Icon name="Activity" className="text-blue-900"/> 팀 섭리적 DNA 분석 (Analysis)
                            </h4>
                            <p className="text-lg md:text-2xl text-slate-700 leading-loose text-justify border-l-4 border-blue-900 pl-6 md:pl-8 py-6 bg-slate-50/50 rounded-r-xl break-keep shadow-sm">
                                {teamAnalysis.desc}
                            </p>
                        </div>

                        {/* Light & Shadow Grid */}
                        <div className="grid md:grid-cols-2 gap-8 mb-10">
                            <div className="bg-green-50 p-8 rounded-3xl border border-green-100 relative group transition-all hover:shadow-md">
                                <div className="absolute top-6 right-6 text-green-200 group-hover:text-green-300 transition-colors">
                                    <Icon name="ThumbsUp" size={48}/>
                                </div>
                                <h5 className="font-bold text-green-900 mb-6 flex items-center gap-2 text-lg">
                                    <Icon name="CheckCircle" size={24}/> 섭리적 강점 (Providential Light)
                                </h5>
                                <ul className="space-y-6 relative z-10">
                                    {teamAnalysis.strength.split(',').map((s, i) => (
                                        <li key={i} className="flex items-start gap-4 text-slate-700">
                                            <span className="w-2.5 h-2.5 bg-green-500 rounded-full mt-3 shrink-0 shadow-sm"></span>
                                            <span className="font-medium text-green-900/90 leading-loose text-lg md:text-xl break-keep">{s.trim()}</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <div className="bg-red-50 p-8 rounded-3xl border border-red-100 relative group transition-all hover:shadow-md">
                                <div className="absolute top-6 right-6 text-red-200 group-hover:text-red-300 transition-colors">
                                    <Icon name="AlertTriangle" size={48}/>
                                </div>
                                <h5 className="font-bold text-red-900 mb-6 flex items-center gap-2 text-lg">
                                    <Icon name="XCircle" size={24}/> 주의할 그림자 (Shadow)
                                </h5>
                                <ul className="space-y-6 relative z-10">
                                    {teamAnalysis.weakness.split(',').map((s, i) => (
                                        <li key={i} className="flex items-start gap-4 text-slate-700">
                                            <span className="w-2.5 h-2.5 bg-red-500 rounded-full mt-3 shrink-0 shadow-sm"></span>
                                            <span className="font-medium text-red-900/90 leading-loose text-lg md:text-xl break-keep">{s.trim()}</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>

                        {/* Action Plan (NEW) */}
                        <div className="mb-12">
                            <h4 className="font-bold text-slate-900 mb-6 flex items-center gap-2 text-xl font-serif">
                                <Icon name="Map" className="text-emerald-600"/> 단계별 실행 로드맵 (Action Plan)
                            </h4>
                            <div className="grid md:grid-cols-2 gap-6">
                                <div className="bg-emerald-50 border border-emerald-100 p-6 rounded-xl">
                                    <h5 className="font-bold text-emerald-900 mb-3 flex items-center gap-2">
                                        <Icon name="History" size={20}/> 단기 과제 (3개월) - 착수
                                    </h5>
                                    <p className="text-slate-700 leading-relaxed text-lg font-medium">{teamAnalysis.actionPlanShort || "계획 수립 중..."}</p>
                                </div>
                                <div className="bg-blue-50 border border-blue-100 p-6 rounded-xl">
                                    <h5 className="font-bold text-blue-900 mb-3 flex items-center gap-2">
                                        <Icon name="Flag" size={20}/> 장기 과제 (1년) - 안착
                                    </h5>
                                    <p className="text-slate-700 leading-relaxed text-lg font-medium">{teamAnalysis.actionPlanLong || "계획 수립 중..."}</p>
                                </div>
                            </div>
                        </div>

                        {/* Career Roadmap Detailed Section (New Implementation) */}
                        <div className="mb-12">
                            <h4 className="font-bold text-slate-900 mb-6 flex items-center gap-2 text-xl font-serif">
                                <Icon name="TrendingUp" className="text-purple-600"/> 팀원별 상세 커리어 및 직무 가이드 (Individual Career Guide)
                            </h4>
                            <div className="grid gap-6">
                                {team.map((member, idx) => {
                                    const catInfo = getCategoryInfo(getCategory(member.id));
                                    return (
                                        <div key={idx} className="bg-white border border-stone-200 p-6 rounded-2xl shadow-sm hover:border-purple-300 transition-all">
                                            {/* Member Header */}
                                            <div className="flex items-center gap-4 mb-6 pb-4 border-b border-stone-100">
                                                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${catInfo.color} shadow-sm shrink-0`}>
                                                    <Icon name={member.symbol} size={24}/>
                                                </div>
                                                <div>
                                                    <div className="flex items-center gap-2 mb-1">
                                                        {idx === 0 && <span className="bg-blue-900 text-white text-[10px] font-bold px-2 py-0.5 rounded-full tracking-wider">YOU</span>}
                                                        <span className="text-sm font-bold text-stone-400 uppercase tracking-widest">{member.engTitle}</span>
                                                    </div>
                                                    <h5 className="text-xl font-bold text-slate-900 font-serif">{member.title}</h5>
                                                </div>
                                            </div>

                                            {/* HQ vs Field Recommendations */}
                                            <div className="grid md:grid-cols-2 gap-4 mb-6">
                                                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                                                    <div className="flex items-center gap-2 mb-2 font-bold text-slate-700 text-sm">
                                                        <Icon name="Castle" size={16} className="text-slate-500"/>
                                                        본부 및 행정 (HQ)
                                                    </div>
                                                    <p className="text-slate-600 text-base leading-relaxed break-keep">{member.recommendations.hq}</p>
                                                </div>
                                                <div className="bg-amber-50 p-4 rounded-xl border border-amber-100">
                                                    <div className="flex items-center gap-2 mb-2 font-bold text-amber-800 text-sm">
                                                        <Icon name="Flame" size={16} className="text-amber-600"/>
                                                        현장 목회 (Field)
                                                    </div>
                                                    <p className="text-slate-600 text-base leading-relaxed break-keep">{member.recommendations.field}</p>
                                                </div>
                                            </div>

                                            {/* Career Path Badges */}
                                            <div className="mb-4">
                                                <div className="text-xs font-bold text-purple-700 uppercase tracking-widest mb-2 flex items-center gap-1">
                                                    <Icon name="GitBranch" size={12}/> Recommended Career Path
                                                </div>
                                                <div className="flex flex-wrap gap-2">
                                                    {member.roles.map((role, rIdx) => (
                                                        <span key={rIdx} className="px-3 py-1.5 bg-purple-50 text-purple-900 rounded-lg text-sm font-bold border border-purple-100">
                                                            {role}
                                                        </span>
                                                    ))}
                                                </div>
                                            </div>

                                            {/* Education Recommendation */}
                                            <div>
                                                <div className="text-xs font-bold text-blue-700 uppercase tracking-widest mb-2 flex items-center gap-1">
                                                    <Icon name="GraduationCap" size={12}/> Academic & Training
                                                </div>
                                                <p className="text-slate-700 text-base font-medium">{member.growthGuide.education}</p>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>

                         {/* Meeting & Decision Report */}
                         <div className="mb-12 bg-indigo-50/50 rounded-2xl border border-indigo-100 p-8 md:p-10">
                            <h4 className="font-bold text-indigo-900 mb-6 flex items-center gap-2 text-xl font-serif">
                                <Icon name="ListChecks" className="text-indigo-600"/> 협업 및 의사결정 스타일 (Collaboration)
                            </h4>
                            <div className="grid md:grid-cols-2 gap-8 md:gap-10">
                                <div className="bg-white p-6 md:p-8 rounded-xl border border-indigo-100 shadow-sm">
                                    <div className="flex items-center gap-3 mb-4">
                                        <div className="p-2 bg-indigo-100 text-indigo-700 rounded-lg"><Icon name="Users" size={24}/></div>
                                        <h5 className="font-bold text-slate-800 text-xl">회의 분위기 (Meeting Style)</h5>
                                    </div>
                                    <p className="text-lg md:text-xl text-slate-700 leading-loose text-justify break-keep">{teamAnalysis.meetingStyle || "분석 중..."}</p>
                                </div>
                                <div className="bg-white p-6 md:p-8 rounded-xl border border-indigo-100 shadow-sm">
                                    <div className="flex items-center gap-3 mb-4">
                                        <div className="p-2 bg-indigo-100 text-indigo-700 rounded-lg"><Icon name="Gavel" size={24}/></div>
                                        <h5 className="font-bold text-slate-800 text-xl">의사결정 방식 (Decision Making)</h5>
                                    </div>
                                    <p className="text-lg md:text-xl text-slate-700 leading-loose text-justify break-keep">{teamAnalysis.decisionMethod || "분석 중..."}</p>
                                </div>
                            </div>
                        </div>

                        {/* Relational Dynamics Report */}
                        <div className="mb-12 bg-slate-100 rounded-2xl border border-slate-200 p-8 md:p-10">
                            <h4 className="font-bold text-slate-900 mb-6 flex items-center gap-2 text-xl font-serif">
                                <Icon name="Activity" className="text-slate-600"/> 관계 역학 시뮬레이션 (Relationship Dynamics)
                            </h4>
                            <div className="grid md:grid-cols-2 gap-8 md:gap-10">
                                <div className="relative pl-6 md:pl-8 border-l-4 border-blue-800 py-2">
                                    <h5 className="font-bold text-blue-900 mb-3 flex items-center gap-2 text-xl">
                                        <Icon name="Briefcase" size={20}/> 리더(상사) vs 팔로워(참모)
                                    </h5>
                                    <p className="text-lg md:text-xl text-slate-700 leading-loose text-justify italic break-keep">
                                        "{teamAnalysis.leaderStaffDynamic || "분석 중..."}"
                                    </p>
                                </div>
                                <div className="relative pl-6 md:pl-8 border-l-4 border-amber-600 py-2">
                                    <h5 className="font-bold text-amber-800 mb-3 flex items-center gap-2 text-xl">
                                        <Icon name="Church" size={20}/> 목회자 vs 식구(장로/권사)
                                    </h5>
                                    <p className="text-lg md:text-xl text-slate-700 leading-loose text-justify italic break-keep">
                                        "{teamAnalysis.pastorMemberDynamic || "분석 중..."}"
                                    </p>
                                </div>
                            </div>
                        </div>

                        {/* Deep Dive Section (Communication & Conflict) */}
                        <div className="grid md:grid-cols-2 gap-8 md:gap-10 mb-12">
                            <div className="border border-stone-200 rounded-2xl p-8 md:p-10 bg-white shadow-sm">
                                <h5 className="font-bold text-slate-800 mb-4 flex items-center gap-2 text-xl">
                                    <Icon name="MessageCircle" className="text-blue-500"/> 소통 스타일 (Communication)
                                </h5>
                                <p className="text-lg md:text-xl text-slate-700 leading-loose text-justify break-keep">
                                    {teamAnalysis.communication}
                                </p>
                            </div>
                            <div className="border border-stone-200 rounded-2xl p-8 md:p-10 bg-white shadow-sm">
                                <h5 className="font-bold text-slate-800 mb-4 flex items-center gap-2 text-xl">
                                    <Icon name="Zap" className="text-amber-500"/> 갈등 트리거 (Conflict Trigger)
                                </h5>
                                <p className="text-lg md:text-xl text-slate-700 leading-loose text-justify break-keep">
                                    {teamAnalysis.conflictTrigger}
                                </p>
                            </div>
                        </div>

                        {/* Future Forecast */}
                        <div className="bg-stone-900 text-stone-200 p-10 md:p-14 rounded-2xl mb-12 relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl -mr-16 -mt-16"></div>
                            <h5 className="font-bold text-white mb-6 flex items-center gap-2 text-xl relative z-10">
                                <Icon name="Compass" className="text-amber-400"/> 1년 후 미래 예측 (Forecast)
                            </h5>
                            <p className="leading-loose text-justify relative z-10 font-serif italic text-xl md:text-3xl opacity-90 break-keep">
                                "{teamAnalysis.futureForecast}"
                            </p>
                        </div>

                        {/* Action Item */}
                        <div className="bg-amber-50 p-8 md:p-12 rounded-2xl border-2 border-amber-200/60 shadow-sm flex flex-col md:flex-row gap-8 items-start">
                            <div className="bg-amber-100 p-5 rounded-2xl text-amber-600 shrink-0">
                                <Icon name="Target" size={40}/>
                            </div>
                            <div>
                                <h4 className="font-bold text-amber-900 mb-3 text-xl md:text-2xl">성공을 위한 협업 가이드 (Key to Success)</h4>
                                <p className="text-amber-900/90 leading-loose font-medium text-lg md:text-2xl break-keep">
                                    {teamAnalysis.advice}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* 2. Member Roles in Team */}
                <div className="bg-white p-10 rounded-3xl border border-stone-200 shadow-sm">
                    <h4 className="text-xl font-bold text-slate-900 mb-8 font-serif flex items-center gap-2">
                        <Icon name="User" className="text-stone-400"/> 팀원별 역할 포지션 (Role Definition)
                    </h4>
                    <div className="grid md:grid-cols-3 gap-6">
                        {team.map((member, idx) => {
                            const cat = getCategory(member.id);
                            const catInfo = getCategoryInfo(cat);
                            const roleInfo = teamRoleDefinitions[member.id] || { roleName: "", contribution: "", task: "", icon: "Briefcase", theme: "stone" };
                            const themeClasses = getThemeClasses(roleInfo.theme);

                            return (
                                <div key={idx} className="relative group h-full">
                                    <div className={`absolute inset-0 bg-white rounded-2xl translate-x-2 translate-y-2 border border-stone-200 transition-transform group-hover:translate-x-3 group-hover:translate-y-3`}></div>
                                    <div className={`relative bg-white p-8 rounded-2xl border-2 transition-all h-full flex flex-col ${idx === 0 ? 'border-blue-900 shadow-md' : 'border-stone-200 hover:border-blue-300'}`}>
                                        {/* Card Header */}
                                        <div className="flex justify-between items-start mb-6">
                                            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${catInfo.color} shadow-sm`}>
                                                <Icon name={member.symbol} size={24}/>
                                            </div>
                                            {idx === 0 && <span className="bg-blue-900 text-white text-[10px] font-bold px-2 py-1 rounded-full tracking-wider">YOU</span>}
                                        </div>
                                        <h5 className="font-bold text-xl text-slate-900 mb-1 font-serif">{member.title}</h5>
                                        <p className="text-sm font-bold text-stone-400 mb-4 uppercase tracking-wider">{member.engTitle}</p>
                                        
                                        <div className="mt-auto space-y-5">
                                            {/* Role Badge */}
                                            <div className={`mt-2 mb-6 p-4 rounded-xl border-2 flex items-center gap-4 ${themeClasses.bg} ${themeClasses.accent}`}>
                                                <div className={`w-12 h-12 rounded-full flex items-center justify-center shadow-sm ${themeClasses.iconBg} ${themeClasses.text}`}>
                                                    <Icon name={roleInfo.icon} size={24}/>
                                                </div>
                                                <div>
                                                    <div className={`text-xs font-bold uppercase tracking-wider opacity-70 ${themeClasses.text}`}>Assigned Role</div>
                                                    <div className={`text-xl font-bold font-serif ${themeClasses.text}`}>{roleInfo.roleName.split('(')[0]}</div>
                                                    <div className={`text-xs font-bold opacity-70 ${themeClasses.text}`}>{roleInfo.roleName.split('(')[1]?.replace(')', '')}</div>
                                                </div>
                                            </div>
                                            
                                            {/* Contribution */}
                                            <div>
                                                <div className="text-sm font-bold text-blue-900 mb-1 flex items-center gap-1 uppercase tracking-wide">
                                                    <Icon name="Zap" size={12}/> Contribution
                                                </div>
                                                <p className="text-sm text-slate-600 leading-relaxed break-keep">{roleInfo.contribution}</p>
                                            </div>

                                            {/* Key Tasks */}
                                            <div>
                                                <div className="text-sm font-bold text-amber-700 mb-1 flex items-center gap-1 uppercase tracking-wide">
                                                    <Icon name="Target" size={12}/> Key Tasks
                                                </div>
                                                <p className="text-sm text-slate-600 leading-relaxed break-keep">{roleInfo.task}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        );
    };

    return (
        <div className="space-y-12 fade-in">
            {/* 1. Header & Partner Selection */}
            <div className="text-center mb-8">
                <h3 className="text-3xl font-bold text-blue-900 mb-4 font-serif">천일국 팀 빌딩 시뮬레이션</h3>
                <p className="text-lg text-slate-600">함께 사역할 파트너를 선택하여 섭리적 시너지를 확인하세요.</p>
            </div>

            {/* Partner Selection Area */}
            <div className="bg-white p-8 rounded-3xl border border-stone-200 shadow-md">
                <h4 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                    <Icon name="UserPlus" className="text-blue-500"/> 파트너 선택 (최대 2명)
                </h4>
                
                <div className="flex gap-4 overflow-x-auto pb-4 custom-scrollbar">
                    {/* My Card (Fixed) */}
                    <div className="min-w-[200px] p-4 bg-blue-50 border-2 border-blue-900 rounded-2xl flex flex-col items-center text-center opacity-80 cursor-not-allowed">
                        <div className="text-xs font-bold text-blue-900 uppercase mb-2">YOU</div>
                        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-blue-900 mb-3 shadow-sm">
                            <Icon name={myArchetype.symbol} size={24}/>
                        </div>
                        <div className="font-bold text-slate-900 text-sm">{myArchetype.title}</div>
                    </div>

                    {/* Available Partners */}
                    {archetypes.map(a => {
                        if (a.id === myArchetype.id) return null;
                        const isSelected = partners.some(p => p.id === a.id);
                        return (
                            <button 
                                key={a.id}
                                onClick={() => togglePartner(a)}
                                className={`min-w-[200px] p-4 rounded-2xl flex flex-col items-center text-center transition-all border-2 ${
                                    isSelected 
                                        ? 'bg-amber-50 border-amber-500 shadow-md scale-105' 
                                        : 'bg-white border-stone-100 hover:border-blue-300 hover:shadow-sm'
                                }`}
                            >
                                <div className="text-xs font-bold text-stone-400 uppercase mb-2">Type {a.id}</div>
                                <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-3 shadow-sm transition-colors ${isSelected ? 'bg-amber-500 text-white' : 'bg-stone-50 text-stone-400'}`}>
                                    <Icon name={a.symbol} size={24}/>
                                </div>
                                <div className={`font-bold text-sm ${isSelected ? 'text-amber-900' : 'text-slate-600'}`}>{a.title}</div>
                            </button>
                        );
                    })}
                </div>
            </div>

            {/* Saved Teams List */}
            {savedTeams.length > 0 && (
                <div className="bg-stone-50 p-6 rounded-2xl border border-stone-200">
                    <h4 className="text-lg font-bold text-slate-700 mb-4 flex items-center gap-2">
                        <Icon name="History" size={18}/> 저장된 팀 기록
                    </h4>
                    <div className="flex flex-wrap gap-3">
                        {savedTeams.map(team => (
                            <div key={team.id} className="bg-white px-4 py-2 rounded-lg border border-stone-200 shadow-sm flex items-center gap-3 hover:border-blue-300 transition-colors cursor-pointer" onClick={() => handleLoadTeam(team)}>
                                <span className="font-bold text-slate-800">{team.name}</span>
                                <span className="text-xs text-stone-400 bg-stone-100 px-2 py-0.5 rounded">{new Date(team.createdAt).toLocaleDateString()}</span>
                                <button 
                                    onClick={(e) => { e.stopPropagation(); handleDeleteTeam(team.id); }}
                                    className="text-stone-300 hover:text-red-500 transition-colors"
                                >
                                    <Icon name="X" size={14}/>
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {renderAnalysis()}
        </div>
    );
};