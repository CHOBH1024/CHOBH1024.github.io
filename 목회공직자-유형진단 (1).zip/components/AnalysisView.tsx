import React, { useState, useMemo, useEffect } from 'react';
import { Icon } from './Icon';
import { detailData } from '../data';
import { Archetype, Inputs, SavedAnalysis } from '../types';
import { TeamBuilder } from './TeamBuilder';

interface AnalysisViewProps {
    results: Archetype[];
    inputs: Inputs;
    onRestore: (inputs: Inputs) => void;
}

// --- Radar Chart Component ---
const ArchetypeRadarChart: React.FC<{ data: Archetype[] }> = ({ data }) => {
    // Sort by ID to ensure consistent axes position (Type 1 is always top)
    const sortedData = [...data].sort((a, b) => a.id - b.id);
    
    const size = 320;
    const center = size / 2;
    const radius = 100;
    const maxScore = Math.max(...data.map(d => d.score || 0)) || 1; // Prevent div by 0

    // Helper to calculate coordinates
    const getCoords = (score: number, index: number, total: number, scaleRadius: number) => {
        const angle = (Math.PI * 2 * index) / total - Math.PI / 2; // Start at 12 o'clock
        const normalizedScore = score / maxScore;
        const x = center + scaleRadius * normalizedScore * Math.cos(angle);
        const y = center + scaleRadius * normalizedScore * Math.sin(angle);
        return { x, y };
    };

    // Generate Polygon Points
    const points = sortedData.map((d, i) => {
        const { x, y } = getCoords(d.score || 0, i, 9, radius);
        return `${x},${y}`;
    }).join(' ');

    // Generate Background Levels (Grid)
    const levels = [0.25, 0.5, 0.75, 1];

    return (
        <div className="flex flex-col items-center">
            <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="max-w-full">
                {/* Background Circles/Polygons */}
                {levels.map((level, lvlIdx) => (
                    <polygon
                        key={lvlIdx}
                        points={sortedData.map((_, i) => {
                            const { x, y } = getCoords(maxScore, i, 9, radius * level);
                            return `${x},${y}`;
                        }).join(' ')}
                        fill="none"
                        stroke="#e7e5e4" // stone-200
                        strokeWidth="1"
                        strokeDasharray={lvlIdx === levels.length - 1 ? "0" : "4 4"}
                    />
                ))}

                {/* Axes Lines */}
                {sortedData.map((_, i) => {
                    const { x, y } = getCoords(maxScore, i, 9, radius);
                    return (
                        <line
                            key={i}
                            x1={center}
                            y1={center}
                            x2={x}
                            y2={y}
                            stroke="#e7e5e4"
                            strokeWidth="1"
                        />
                    );
                })}

                {/* Data Polygon */}
                <polygon
                    points={points}
                    fill="rgba(30, 58, 138, 0.2)" // blue-900 with opacity
                    stroke="#1e3a8a" // blue-900
                    strokeWidth="2.5"
                    className="drop-shadow-md transition-all duration-1000 ease-out animate-[scaleUp_1s_ease-out]"
                />

                {/* Data Points (Dots) */}
                {sortedData.map((d, i) => {
                    const { x, y } = getCoords(d.score || 0, i, 9, radius);
                    return (
                        <circle
                            key={i}
                            cx={x}
                            cy={y}
                            r="4"
                            fill={d.score === maxScore ? "#f59e0b" : "#1e3a8a"} // Amber for max, Blue for others
                            className="transition-all duration-1000"
                        />
                    );
                })}

                {/* Labels */}
                {sortedData.map((d, i) => {
                    const { x, y } = getCoords(maxScore, i, 9, radius + 25);
                    // Adjust text anchor based on position
                    const anchor = Math.abs(x - center) < 10 ? 'middle' : x > center ? 'start' : 'end';
                    return (
                        <g key={i}>
                            <text
                                x={x}
                                y={y}
                                textAnchor={anchor}
                                alignmentBaseline="middle"
                                className={`text-[10px] md:text-xs font-bold fill-slate-600 font-serif ${d.score === maxScore ? 'fill-blue-900 font-black' : ''}`}
                            >
                                {d.id}. {d.title}
                            </text>
                        </g>
                    );
                })}
            </svg>
        </div>
    );
};

// Helper to convert Big5 to MBTI-like code for display
const getMBTI = (big5: Inputs['big5']): string => {
    let mbti = '';
    mbti += big5.extraversion === 'High' ? 'E' : big5.extraversion === 'Low' ? 'I' : 'x';
    mbti += big5.openness === 'High' ? 'N' : big5.openness === 'Low' ? 'S' : 'x';
    mbti += big5.agreeableness === 'High' ? 'F' : big5.agreeableness === 'Low' ? 'T' : 'x';
    mbti += big5.conscientiousness === 'High' ? 'J' : big5.conscientiousness === 'Low' ? 'P' : 'x';
    return mbti.replace(/x/g, '-'); 
};

export const AnalysisView: React.FC<AnalysisViewProps> = ({ results, inputs, onRestore }) => {
    const [tab, setTab] = useState<'details' | 'cross_analysis' | 'growth' | 'team'>('details');
    const [savedAnalyses, setSavedAnalyses] = useState<SavedAnalysis[]>([]);
    const [saveName, setSaveName] = useState('');
    const [showSaveUI, setShowSaveUI] = useState(false);

    // Primary result is the first element
    const result = results.length > 0 ? results[0] : null;

    // Load saved analyses
    useEffect(() => {
        const stored = localStorage.getItem('cig_saved_analyses');
        if (stored) {
            try {
                setSavedAnalyses(JSON.parse(stored));
            } catch (e) {
                console.error("Failed to parse saved analyses", e);
            }
        }
    }, []);

    const handleSaveAnalysis = () => {
        if (!saveName.trim()) {
            alert("저장할 이름을 입력해주세요.");
            return;
        }
        if (!result) return;

        const newAnalysis: SavedAnalysis = {
            id: Date.now().toString(),
            name: saveName,
            inputs: inputs,
            resultTitle: result.title,
            createdAt: Date.now()
        };

        const updated = [newAnalysis, ...savedAnalyses];
        setSavedAnalyses(updated);
        localStorage.setItem('cig_saved_analyses', JSON.stringify(updated));
        setSaveName('');
        setShowSaveUI(false);
        alert("분석 결과가 저장되었습니다.");
    };

    const handleDeleteAnalysis = (id: string) => {
        if (confirm("정말 이 기록을 삭제하시겠습니까?")) {
            const updated = savedAnalyses.filter(a => a.id !== id);
            setSavedAnalyses(updated);
            localStorage.setItem('cig_saved_analyses', JSON.stringify(updated));
        }
    };

    const handleLoadAnalysis = (analysis: SavedAnalysis) => {
        if (confirm(`'${analysis.name}' 기록을 불러오시겠습니까? 현재 화면의 분석 내용은 변경됩니다.`)) {
            onRestore(analysis.inputs);
        }
    };

    // Calculate match metrics for the primary result
    const matchMetrics = useMemo(() => {
        if (!result) return null;

        const dominantTrait = result.traits.big5;
        const userLevel = inputs.big5[dominantTrait];
        const isBig5Match = userLevel === 'High';
        const isAnchorMatch = result.traits.anchor.includes(inputs.anchor);
        const matchedVia = inputs.via.filter(v => result.traits.via.includes(v));
        
        return { isBig5Match, isAnchorMatch, matchedVia, userLevel };
    }, [result, inputs]);

    if (!result || !matchMetrics) return null;

    const userMBTI = getMBTI(inputs.big5);
    const userAnchorLabel = detailData.anchor[inputs.anchor]?.label;
    const maxScore = Math.max(...results.map(r => r.score || 0));

    return (
        <div className="max-w-7xl mx-auto px-6 py-12 fade-in">
            {/* Save/Load Control Bar */}
            <div className="mb-8 flex flex-col md:flex-row justify-between items-center gap-4">
                <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                    <Icon name="User" className="text-blue-900"/> 분석 결과 대시보드
                </h2>
                <div className="flex gap-2">
                    <button 
                        onClick={() => setShowSaveUI(!showSaveUI)}
                        className="px-4 py-2 bg-amber-50 text-amber-700 rounded-lg font-bold hover:bg-amber-100 transition-colors flex items-center gap-2 text-base border border-amber-200"
                    >
                        <Icon name="Save" size={16}/> 결과 저장
                    </button>
                    {savedAnalyses.length > 0 && (
                        <div className="relative group">
                            <button className="px-4 py-2 bg-stone-50 text-stone-700 rounded-lg font-bold hover:bg-stone-100 transition-colors flex items-center gap-2 text-base border border-stone-200">
                                <Icon name="BookOpen" size={16}/> 불러오기 ({savedAnalyses.length})
                            </button>
                            <div className="absolute right-0 top-full mt-2 w-72 bg-white rounded-xl shadow-xl border border-stone-200 overflow-hidden hidden group-hover:block z-50">
                                <div className="p-3 bg-stone-50 border-b border-stone-100 text-sm font-bold text-stone-500">저장된 분석 기록</div>
                                <div className="max-h-64 overflow-y-auto">
                                    {savedAnalyses.map(a => (
                                        <div key={a.id} className="p-3 hover:bg-blue-50 border-b border-stone-50 flex justify-between items-center group/item transition-colors cursor-pointer" onClick={() => handleLoadAnalysis(a)}>
                                            <div>
                                                <div className="font-bold text-slate-800 text-base">{a.name}</div>
                                                <div className="text-sm text-stone-500 mt-0.5">{a.resultTitle} • {new Date(a.createdAt).toLocaleDateString()}</div>
                                            </div>
                                            <button 
                                                onClick={(e) => { e.stopPropagation(); handleDeleteAnalysis(a.id); }}
                                                className="p-1.5 text-stone-300 hover:text-red-500 hover:bg-red-50 rounded-md transition-colors"
                                            >
                                                <Icon name="X" size={14}/>
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* Save UI Panel */}
            {showSaveUI && (
                <div className="mb-8 bg-amber-50 p-6 rounded-2xl border border-amber-200 animate-[slideUp_0.3s_ease-out]">
                    <h4 className="font-bold text-amber-900 mb-3 flex items-center gap-2">
                        <Icon name="Save" size={18}/> 현재 분석 결과 저장하기
                    </h4>
                    <div className="flex gap-2">
                        <input 
                            type="text" 
                            value={saveName}
                            onChange={(e) => setSaveName(e.target.value)}
                            placeholder="저장할 이름 (예: 홍길동 2024년 1분기)"
                            className="flex-grow px-4 py-2 rounded-lg border border-amber-300 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
                        />
                        <button 
                            onClick={handleSaveAnalysis}
                            className="px-6 py-2 bg-amber-600 text-white font-bold rounded-lg hover:bg-amber-700 transition-colors shadow-sm"
                        >
                            저장
                        </button>
                    </div>
                </div>
            )}

            {/* Common Header Section */}
            <div className="bg-white rounded-3xl shadow-2xl overflow-hidden border border-stone-200 text-center relative mb-12">
                <div className="bg-slate-900 p-12 md:p-16 text-white relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
                    <span className="inline-block px-4 py-1 border border-amber-500/50 rounded-full text-amber-400 text-sm font-bold tracking-[0.2em] uppercase mb-6">Cheon Il Guk Archetype</span>
                    <h2 className="text-4xl md:text-6xl font-serif font-bold mb-4">{result.title}</h2>
                    <p className="text-xl text-slate-400 font-serif italic mb-8">{result.engTitle}</p>
                    <p className="text-lg md:text-xl text-stone-200 font-serif max-w-4xl mx-auto leading-relaxed border-l-4 border-amber-600 pl-6">"{result.verse}"</p>
                </div>
            </div>

            {/* Tab Navigation */}
            <div className="flex justify-center gap-2 md:gap-8 mb-12 border-b border-stone-200 sticky top-20 bg-[#fcfbf9] z-30 pt-4 overflow-x-auto">
                <button 
                    onClick={() => setTab('details')} 
                    className={`pb-4 px-4 text-lg md:text-2xl font-serif transition-all flex items-center gap-2 whitespace-nowrap ${tab==='details' ? 'text-blue-900 font-bold border-b-4 border-blue-900' : 'text-stone-400 hover:text-stone-600'}`}
                >
                    <Icon name="User" size={24} /> <span className="hidden md:inline">아키타입 </span>상세
                </button>
                <button 
                    onClick={() => setTab('cross_analysis')} 
                    className={`pb-4 px-4 text-lg md:text-2xl font-serif transition-all flex items-center gap-2 whitespace-nowrap ${tab==='cross_analysis' ? 'text-blue-900 font-bold border-b-4 border-blue-900' : 'text-stone-400 hover:text-stone-600'}`}
                >
                    <Icon name="Activity" size={24} /> 교차 분석
                </button>
                <button 
                    onClick={() => setTab('growth')} 
                    className={`pb-4 px-4 text-lg md:text-2xl font-serif transition-all flex items-center gap-2 whitespace-nowrap ${tab==='growth' ? 'text-blue-900 font-bold border-b-4 border-blue-900' : 'text-stone-400 hover:text-stone-600'}`}
                >
                    <Icon name="Sprout" size={24} /> 성장 가이드
                </button>
                <button 
                    onClick={() => setTab('team')} 
                    className={`pb-4 px-4 text-lg md:text-2xl font-serif transition-all flex items-center gap-2 whitespace-nowrap ${tab==='team' ? 'text-blue-900 font-bold border-b-4 border-blue-900' : 'text-stone-400 hover:text-stone-600'}`}
                >
                    <Icon name="Users" size={24} /> 팀 시뮬레이션
                </button>
            </div>

            {/* Content Body */}
            <div className="slide-up">
                {tab === 'details' && (
                    <div className="space-y-16">
                        {/* 1. Identity & Theology */}
                        <section className="grid lg:grid-cols-12 gap-12">
                            <div className="lg:col-span-8">
                                <h3 className="text-3xl font-bold text-blue-900 mb-6 font-serif flex items-center gap-3">
                                    <Icon name="BookOpen" className="text-blue-900"/> 
                                    정체성 및 섭리적 맥락
                                </h3>
                                <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm mb-8">
                                    <h4 className="text-xl font-bold text-slate-900 mb-4 font-serif">"{result.subtitle}"</h4>
                                    <p className="text-xl text-slate-700 leading-loose text-justify font-serif mb-6">{result.summary}</p>
                                    <div className="bg-blue-50 p-6 rounded-xl text-blue-900 text-base leading-relaxed border border-blue-100">
                                        <strong><Icon name="Briefcase" className="inline mr-2" size={16}/>공직 가이드:</strong> {result.details.guide}
                                    </div>
                                </div>

                                {/* DNA Table */}
                                <h3 className="text-3xl font-bold text-blue-900 mb-6 font-serif flex items-center gap-3">
                                    <Icon name="Dna" className="text-purple-600"/> 
                                    섭리적 DNA (작동원리)
                                </h3>
                                <div className="grid md:grid-cols-3 gap-0 border border-stone-200 rounded-3xl overflow-hidden shadow-lg mb-8">
                                    <div className="bg-white p-6 md:border-r border-stone-200">
                                        <div className="text-sm font-bold text-stone-400 tracking-widest mb-2">BEHAVIOR</div>
                                        <h4 className="text-xl font-serif font-bold text-slate-900 mb-3">HOW (행동)</h4>
                                        <p className="text-slate-600 leading-relaxed text-base">{result.dna.how}</p>
                                    </div>
                                    <div className="bg-stone-50 p-6 md:border-r border-stone-200">
                                        <div className="text-sm font-bold text-stone-400 tracking-widest mb-2">STRENGTH</div>
                                        <h4 className="text-xl font-serif font-bold text-slate-900 mb-3">WHAT (강점)</h4>
                                        <p className="text-slate-600 leading-relaxed text-base">{result.dna.what}</p>
                                    </div>
                                    <div className="bg-white p-6">
                                        <div className="text-sm font-bold text-stone-400 tracking-widest mb-2">MOTIVATION</div>
                                        <h4 className="text-xl font-serif font-bold text-slate-900 mb-3">WHY (동기)</h4>
                                        <p className="text-slate-600 leading-relaxed text-base">{result.dna.why}</p>
                                    </div>
                                </div>
                            </div>

                            {/* Sidebar: Development & Caution */}
                            <div className="lg:col-span-4 space-y-6">
                                <div className="bg-slate-800 text-white p-8 rounded-2xl shadow-xl">
                                    <h3 className="text-xl font-bold text-white mb-4 font-serif flex items-center gap-2"><Icon name="Sprout" className="text-green-400"/> 필수 성장 과제</h3>
                                    <p className="text-slate-300 text-base leading-relaxed text-justify opacity-90">{result.details.development}</p>
                                </div>
                                <div className="bg-amber-50 p-8 rounded-2xl border border-amber-200">
                                    <h3 className="text-xl font-bold text-amber-800 mb-4 font-serif flex items-center gap-2"><Icon name="AlertTriangle"/> 섭리적 주의사항</h3>
                                    <p className="text-slate-700 text-base leading-relaxed text-justify">{result.details.caution}</p>
                                </div>
                            </div>
                        </section>

                        {/* 2. Contextual Recommendations (HQ vs Field) */}
                        <section>
                            <h3 className="text-3xl font-bold text-blue-900 mb-8 font-serif flex items-center gap-3">
                                <Icon name="Map" className="text-emerald-600"/> 
                                직무 환경별 역할 제안 (Contextual Roles)
                            </h3>
                            <div className="grid md:grid-cols-2 gap-8">
                                <div className="bg-white p-8 rounded-2xl border-l-8 border-slate-700 shadow-lg relative overflow-hidden group">
                                    <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                                        <Icon name="Castle" size={120} />
                                    </div>
                                    <h4 className="text-2xl font-bold text-slate-900 mb-4 font-serif flex items-center gap-3">
                                        <span className="bg-slate-100 p-2 rounded-lg text-slate-700"><Icon name="Castle" size={24}/></span>
                                        본부 및 행정 (HQ)
                                    </h4>
                                    <p className="text-slate-700 text-lg leading-loose text-justify font-medium relative z-10">
                                        {result.recommendations?.hq}
                                    </p>
                                </div>
                                <div className="bg-white p-8 rounded-2xl border-l-8 border-amber-600 shadow-lg relative overflow-hidden group">
                                    <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                                        <Icon name="Flame" size={120} />
                                    </div>
                                    <h4 className="text-2xl font-bold text-slate-900 mb-4 font-serif flex items-center gap-3">
                                        <span className="bg-amber-50 p-2 rounded-lg text-amber-600"><Icon name="Flame" size={24}/></span>
                                        현장 목회 (Field Ministry)
                                    </h4>
                                    <p className="text-slate-700 text-lg leading-loose text-justify font-medium relative z-10">
                                        {result.recommendations?.field}
                                    </p>
                                </div>
                            </div>
                        </section>

                        {/* 3. Roles & Prediction */}
                        <section>
                             <h3 className="text-3xl font-bold text-blue-900 mb-8 font-serif flex items-center gap-3">
                                <Icon name="Compass" className="text-red-500"/> 
                                공직 생활 시뮬레이션
                            </h3>
                            <div className="grid md:grid-cols-2 gap-8">
                                <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm">
                                    <h4 className="text-xl font-bold text-slate-900 mb-4 font-serif flex items-center gap-2"><Icon name="Activity"/> 행동 패턴 예측</h4>
                                    <p className="text-slate-700 text-lg leading-relaxed text-justify italic border-l-4 border-slate-300 pl-4 bg-slate-50 py-4 pr-4 rounded-r-lg">
                                        "{result.prediction}"
                                    </p>
                                </div>
                                <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm">
                                    <h4 className="text-xl font-bold text-slate-900 mb-4 font-serif flex items-center gap-2"><Icon name="Briefcase"/> 주요 활동 시나리오</h4>
                                    <ul className="space-y-3">
                                        {result.activities.map((act, i) => (
                                            <li key={i} className="flex items-start gap-3 text-slate-700 text-base">
                                                <span className="mt-1.5 w-1.5 h-1.5 bg-blue-500 rounded-full flex-shrink-0"></span>
                                                {act}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        </section>
                    </div>
                )}

                {tab === 'cross_analysis' && (
                    <div className="space-y-16">
                        {/* 1. Holistic Chart (Refactored with Radar Chart) */}
                        <section>
                             <h3 className="text-3xl font-bold text-blue-900 mb-8 font-serif flex items-center gap-3">
                                <Icon name="Activity" className="text-amber-600"/> 
                                전체 아키타입 분포도 (Holistic Analysis)
                            </h3>
                            <div className="bg-white p-8 lg:p-12 rounded-2xl border border-stone-200 shadow-sm">
                                <div className="grid lg:grid-cols-2 gap-12 items-center">
                                    {/* Left: Radar Chart */}
                                    <div className="flex justify-center order-2 lg:order-1 bg-slate-50 rounded-3xl p-6">
                                        <ArchetypeRadarChart data={results} />
                                    </div>
                                    
                                    {/* Right: Ranking & Insight */}
                                    <div className="order-1 lg:order-2 space-y-6">
                                        <div>
                                            <h4 className="text-2xl font-bold text-slate-900 mb-4 font-serif">당신의 섭리적 스펙트럼</h4>
                                            <p className="text-slate-600 mb-6 text-base leading-relaxed text-justify">
                                                당신의 내면에는 하나의 색깔만 있는 것이 아닙니다. 
                                                <strong className="text-blue-900"> {result.title}</strong>(이)가 주된 성향이지만, 
                                                그래프의 모양을 통해 당신에게 잠재된 <strong className="text-amber-600">보조 은사(Secondary Gift)</strong>와 
                                                상대적으로 개발이 필요한 영역을 한눈에 확인할 수 있습니다.
                                                그래프가 넓고 고르게 분포할수록 다양한 사역을 감당할 수 있는 균형 잡힌 리더십을 의미합니다.
                                            </p>
                                        </div>
                                        
                                        <div className="space-y-3 h-80 overflow-y-auto pr-2 custom-scrollbar">
                                            {results.map((r, idx) => {
                                                const percentage = ((r.score || 0) / maxScore) * 100;
                                                const isTop = idx === 0;
                                                return (
                                                    <div key={r.id} className="relative group">
                                                        <div className="flex justify-between items-end mb-1">
                                                            <div className="flex items-center gap-2">
                                                                <span className={`text-sm font-bold w-6 ${isTop ? 'text-blue-900' : 'text-slate-400'}`}>
                                                                    {idx + 1}
                                                                </span>
                                                                <span className={`text-base font-bold ${isTop ? 'text-blue-900' : 'text-slate-700'}`}>
                                                                    {r.title}
                                                                </span>
                                                            </div>
                                                            <span className="text-xs text-stone-400 font-mono">{Math.round(r.score || 0)} pts</span>
                                                        </div>
                                                        <div className="w-full bg-stone-100 rounded-full h-2.5 overflow-hidden">
                                                            <div 
                                                                className={`h-2.5 rounded-full transition-all duration-1000 ${isTop ? 'bg-blue-900' : 'bg-stone-300 group-hover:bg-blue-300'}`}
                                                                style={{ width: `${percentage}%` }}
                                                            ></div>
                                                        </div>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        {/* 2. Comparative Analysis */}
                        <section>
                            <h3 className="text-3xl font-bold text-blue-900 mb-8 font-serif flex items-center gap-3">
                                <Icon name="Scale" className="text-amber-600"/> 
                                나의 속성 vs 아키타입 비교 (Gap Analysis)
                            </h3>
                            <div className="grid md:grid-cols-3 gap-6">
                                {/* MBTI / Behavior */}
                                <div className={`p-6 rounded-2xl border-2 ${matchMetrics.isBig5Match ? 'bg-blue-50 border-blue-200' : 'bg-white border-stone-200'}`}>
                                    <div className="flex justify-between items-start mb-4">
                                        <h4 className="font-bold text-slate-700 flex items-center gap-2"><Icon name="Activity" size={18}/> 행동양식 (MBTI/Big5)</h4>
                                        {matchMetrics.isBig5Match && <span className="bg-blue-100 text-blue-800 text-sm font-bold px-2 py-1 rounded">일치</span>}
                                    </div>
                                    <div className="text-2xl font-black text-slate-900 mb-2">INPUT: {userMBTI}</div>
                                    <p className="text-base text-slate-600 mb-4">
                                        {matchMetrics.isBig5Match 
                                            ? `귀하의 특성이 이 아키타입의 주요 특성(${detailData.big5[result.traits.big5].name})과 잘 부합합니다.` 
                                            : `이 아키타입은 '${detailData.big5[result.traits.big5].name}' 성향이 강합니다. 귀하와는 접근 방식에 차이가 있을 수 있습니다.`}
                                    </p>
                                </div>

                                {/* Anchor / Motivation */}
                                <div className={`p-6 rounded-2xl border-2 ${matchMetrics.isAnchorMatch ? 'bg-blue-50 border-blue-200' : 'bg-white border-stone-200'}`}>
                                    <div className="flex justify-between items-start mb-4">
                                        <h4 className="font-bold text-slate-700 flex items-center gap-2"><Icon name="Anchor" size={18}/> 동기요인 (앵커)</h4>
                                        {matchMetrics.isAnchorMatch ? 
                                            <span className="bg-blue-100 text-blue-800 text-sm font-bold px-2 py-1 rounded">일치</span> : 
                                            <span className="bg-stone-100 text-stone-600 text-sm font-bold px-2 py-1 rounded">관점 차이</span>
                                        }
                                    </div>
                                    <div className="text-2xl font-black text-slate-900 mb-2">INPUT: {userAnchorLabel}</div>
                                    <p className="text-base text-slate-600 mb-4">
                                        {matchMetrics.isAnchorMatch 
                                            ? "직업적 가치관이 아키타입의 방향성과 일치하여 높은 섭리적 만족도가 예상됩니다."
                                            : `이 유형은 보통 '${result.traits.anchor.map(a => detailData.anchor[a].label).join(', ')}' 지향적입니다. 상호 보완적 노력이 필요합니다.`}
                                    </p>
                                </div>

                                {/* VIA / Strength */}
                                <div className="p-6 rounded-2xl border-2 bg-blue-50 border-blue-200">
                                    <div className="flex justify-between items-start mb-4">
                                        <h4 className="font-bold text-slate-700 flex items-center gap-2"><Icon name="Sparkles" size={18}/> 핵심강점 (VIA)</h4>
                                        <span className="bg-blue-100 text-blue-800 text-sm font-bold px-2 py-1 rounded">{matchMetrics.matchedVia.length}건 일치</span>
                                    </div>
                                    <div className="flex flex-wrap gap-2 mb-4">
                                        {matchMetrics.matchedVia.map(v => (
                                            <span key={v} className="px-2 py-1 bg-white border border-blue-200 rounded text-sm font-bold text-blue-800">{v}</span>
                                        ))}
                                        {matchMetrics.matchedVia.length === 0 && <span className="text-base text-stone-400">일치하는 주요 강점이 없습니다.</span>}
                                    </div>
                                    <p className="text-base text-slate-600">
                                        귀하의 강점 중 {matchMetrics.matchedVia.length > 0 ? matchMetrics.matchedVia.join(', ') : '일부'} 특성이 이 아키타입의 DNA와 공명합니다.
                                    </p>
                                </div>
                            </div>
                        </section>

                         {/* 4. Input Summary (Previously 'detail' tab content) */}
                         <section>
                             <h3 className="text-3xl font-bold text-blue-900 mb-8 font-serif flex items-center gap-3">
                                <Icon name="Fingerprint" className="text-stone-400"/> 
                                나의 진단 데이터 원본
                            </h3>
                            <div className="space-y-6">
                                <div className="bg-white p-6 rounded-2xl border border-stone-200 flex items-start gap-4">
                                    <div className="p-3 bg-purple-50 rounded-lg text-purple-600"><Icon name="Fingerprint"/></div>
                                    <div>
                                        <h4 className="font-bold text-slate-900">Enneagram: {detailData.enneagram[inputs.enneagram]?.label}</h4>
                                        <p className="text-base text-slate-600 mt-1">{detailData.enneagram[inputs.enneagram]?.desc}</p>
                                    </div>
                                </div>
                                <div className="bg-white p-6 rounded-2xl border border-stone-200 flex items-start gap-4">
                                    <div className="p-3 bg-green-50 rounded-lg text-green-600"><Icon name="Brain"/></div>
                                    <div className="w-full">
                                        <h4 className="font-bold text-slate-900 mb-2">Big 5 Profile ({userMBTI})</h4>
                                        <div className="grid grid-cols-5 gap-2 text-sm text-center">
                                            {Object.entries(inputs.big5).map(([key, level]) => (
                                                <div key={key} className={`p-2 rounded ${level==='High'?'bg-green-100 font-bold':level==='Low'?'bg-stone-100 text-stone-400':'bg-stone-50'}`}>
                                                    {key.slice(0,1).toUpperCase()}{key.slice(1,3)}: {level}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                                <div className="bg-white p-6 rounded-2xl border border-stone-200 flex items-start gap-4">
                                    <div className="p-3 bg-blue-50 rounded-lg text-blue-600"><Icon name="Anchor"/></div>
                                    <div>
                                        <h4 className="font-bold text-slate-900">Career Anchor: {detailData.anchor[inputs.anchor]?.label}</h4>
                                        <p className="text-base text-slate-600 mt-1">{detailData.anchor[inputs.anchor]?.desc}</p>
                                    </div>
                                </div>
                                <div className="bg-white p-6 rounded-2xl border border-stone-200 flex items-start gap-4">
                                    <div className="p-3 bg-amber-50 rounded-lg text-amber-600"><Icon name="Sparkles"/></div>
                                    <div>
                                        <h4 className="font-bold text-slate-900 mb-2">Signature Strengths</h4>
                                        <div className="flex flex-wrap gap-2">
                                            {inputs.via.map(v=><span key={v} className="px-2 py-1 bg-amber-50 text-amber-800 rounded-md text-sm font-bold">{v}</span>)}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                )}

                {tab === 'growth' && (
                     <div className="space-y-16 animate-[fadeIn_0.5s_ease-out]">
                        <section className="text-center mb-12">
                             <h3 className="text-3xl font-bold text-blue-900 mb-4 font-serif">
                                공직자를 위한 맞춤형 성장 로드맵
                            </h3>
                            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
                                당신의 아키타입이 가진 잠재력을 100% 발휘하기 위한 구체적인 훈련법입니다.
                                작은 습관의 변화가 위대한 섭리의 결실을 맺습니다.
                            </p>
                        </section>

                        <div className="grid md:grid-cols-3 gap-8">
                            {/* 1. Spiritual Discipline */}
                            <div className="bg-white rounded-3xl overflow-hidden border border-stone-200 shadow-xl hover:-translate-y-2 transition-transform duration-300">
                                <div className="bg-gradient-to-br from-purple-700 to-indigo-800 p-8 text-white relative">
                                    <div className="absolute top-0 right-0 p-4 opacity-20">
                                        <Icon name="Dumbbell" size={80} />
                                    </div>
                                    <h4 className="text-xl font-bold mb-1 flex items-center gap-2">
                                        <Icon name="Dumbbell" size={20}/> 영적 훈련 (Discipline)
                                    </h4>
                                    <p className="text-purple-100 text-sm opacity-90">내면을 단단하게 하는 정성</p>
                                </div>
                                <div className="p-8">
                                    <div className="text-2xl font-bold text-slate-900 font-serif mb-4 leading-tight">
                                        {result.growthGuide?.discipline?.split(':')[0]}
                                    </div>
                                    <p className="text-slate-600 leading-relaxed text-lg">
                                        {result.growthGuide?.discipline?.split(':')[1]}
                                    </p>
                                </div>
                            </div>

                            {/* 2. Professional Skill */}
                            <div className="bg-white rounded-3xl overflow-hidden border border-stone-200 shadow-xl hover:-translate-y-2 transition-transform duration-300">
                                <div className="bg-gradient-to-br from-blue-700 to-cyan-700 p-8 text-white relative">
                                    <div className="absolute top-0 right-0 p-4 opacity-20">
                                        <Icon name="GraduationCap" size={80} />
                                    </div>
                                    <h4 className="text-xl font-bold mb-1 flex items-center gap-2">
                                        <Icon name="GraduationCap" size={20}/> 직무 스킬 (Skill)
                                    </h4>
                                    <p className="text-blue-100 text-sm opacity-90">섭리적 성과를 내는 기술</p>
                                </div>
                                <div className="p-8">
                                     <div className="text-2xl font-bold text-slate-900 font-serif mb-4 leading-tight">
                                        {result.growthGuide?.skill?.split(':')[0]}
                                    </div>
                                    <p className="text-slate-600 leading-relaxed text-lg">
                                        {result.growthGuide?.skill?.split(':')[1]}
                                    </p>
                                </div>
                            </div>

                            {/* 3. Biblical Role Model */}
                            <div className="bg-white rounded-3xl overflow-hidden border border-stone-200 shadow-xl hover:-translate-y-2 transition-transform duration-300">
                                <div className="bg-gradient-to-br from-amber-600 to-orange-700 p-8 text-white relative">
                                    <div className="absolute top-0 right-0 p-4 opacity-20">
                                        <Icon name="Lightbulb" size={80} />
                                    </div>
                                    <h4 className="text-xl font-bold mb-1 flex items-center gap-2">
                                        <Icon name="Lightbulb" size={20}/> 성경적 롤모델 (Model)
                                    </h4>
                                    <p className="text-amber-100 text-sm opacity-90">당신이 닮아야 할 인물</p>
                                </div>
                                <div className="p-8">
                                    <div className="text-2xl font-bold text-slate-900 font-serif mb-4 leading-tight">
                                        {result.growthGuide?.model?.split(':')[0]}
                                    </div>
                                    <p className="text-slate-600 leading-relaxed text-lg">
                                        {result.growthGuide?.model?.split(':')[1]}
                                    </p>
                                </div>
                            </div>
                        </div>

                        {/* Actionable Checklist */}
                        <div className="bg-slate-50 border border-slate-200 rounded-3xl p-10">
                            <h4 className="text-2xl font-bold text-slate-900 mb-8 font-serif flex items-center gap-3">
                                <Icon name="ListChecks" className="text-green-600" size={32}/>
                                이번 주 실천 체크리스트
                            </h4>
                            <div className="space-y-4">
                                {result.growthGuide?.checklist?.map((item, idx) => (
                                    <div key={idx} className="flex items-start gap-4 p-4 bg-white rounded-2xl border border-slate-200 shadow-sm hover:border-blue-300 transition-colors">
                                        <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-800 font-bold flex items-center justify-center shrink-0 mt-1">
                                            {idx + 1}
                                        </div>
                                        <p className="text-lg text-slate-700 font-medium leading-relaxed">
                                            {item}
                                        </p>
                                    </div>
                                ))}
                            </div>
                        </div>
                     </div>
                )}
                
                {tab === 'team' && (
                    <TeamBuilder myArchetype={result} />
                )}
            </div>
        </div>
    );
};